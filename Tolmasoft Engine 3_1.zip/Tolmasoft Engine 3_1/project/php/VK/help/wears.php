<?php    
    newObj(0, 0, 12, 50, 2, 0, array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(1, 1, 45, 180, 2, 0, array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(2, 2, 72, 290, 2, 0, array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(2, 3, 22, 90, 2, 0, array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(3, 4, 12, 50, 2, 0, array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    
    
    newObj(0, 5, 100, 390, 5, 1,  array(5, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(0, 6, 100, 390, 5, 1, array(5, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(0, 7, 100, 450, 5, 1, array(5, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(1, 8, 100, 950, 6, 1, array(0, 0, 0), array(0, 9, 0), array(0, 0, 0), array(0, 9, 0), -1, -1, 0, 'coins', 0);
    newObj(1, 9, 100, 1200, 6, 1, array(0, 0, 0), array(0, 0, 0), array(7, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(1, 10, 100, 900, 6, 1, array(0, 0, 0), array(0, 0, 0), array(0, 0, 7), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(1, 11, 100, 800, 6, 1, array(0, 0, 0), array(0, 0, 0), array(0, 0, 7), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(2, 12, 100, 1900, 7, 1, array(0, 0, 0), array(9, 0, 0), array(0, 0, 0), array(9, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(2, 13, 100, 1700, 7, 1, array(0, 0, 0), array(0, 10, 0), array(0, 0, 0), array(0, 10, 0), -1, -1, 0, 'coins', 0);  
    newObj(3, 14, 100, 3500, 8, 1, array(0, 0, 0), array(12, 0, 0), array(0, 0, 0), array(12, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(3, 15, 100, 4600, 8, 1, array(0, 0, 0), array(0, 0, 12), array(0, 0, 0), array(0, 0, 12), -1, -1, 0, 'coins', 0);
    newObj(3, 16, 100, 4600, 8, 1, array(0, 0, 0), array(0, 12, 0), array(0, 0, 0), array(0, 12, 0), -1, -1, 0, 'coins', 0);
    
    
    newObj(0, 17, 200, 4500, 10, 2, array(8, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(0, 18, 200, 5000, 12, 2, array(0, 0, 0), array(0, 0, 0), array(0, 6, 0), array(0, 0, 0), -1, -1, 0, 'coins', 0);   
    newObj(1, 19, 200, 8000, 15, 2, array(0, 0, 0), array(12, 0, 0), array(0, 0, 0), array(12, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(1, 20, 200, 15000, 18, 2, array(0, 0, 0), array(0, 0, 12), array(0, 0, 0), array(0, 0, 12), -1, -1, 0, 'coins', 0);
    newObj(1, 21, 200, 15000, 19, 2, array(0, 0, 0), array(0, 12, 0), array(0, 0, 0), array(0, 12, 0), -1, -1, 0, 'coins', 0);
    newObj(2, 22, 200, 12000, 20, 2, array(0, 0, 0), array(0, 0, 11), array(0, 0, 0), array(0, 0, 11), -1, -1, 0, 'coins', 0);
    newObj(2, 23, 200, 25000, 21, 2, array(0, 0, 0), array(11, 0, 0), array(0, 0, 0), array(11, 0, 0), -1, -1, 0, 'coins', 0);
    newObj(3, 24, 200, 18000, 24, 2, array(0, 0, 0), array(0, 13, 0), array(0, 0, 0), array(0, 13, 0), -1, -1, 0, 'coins', 0);
    
    
    newObj(0, 25, 0, 1, 0, 3, array(0, 0, 0), array(11, 0, 0), array(0, 0, 0), array(11, 0, 0), 0, -1, 0, 'null', 0);
    newObj(1, 26, 0, 1, 0, 3, array(0, 0, 0), array(0, 0, 11), array(0, 0, 0), array(0, 0, 11), 0, -1, 0, 'null', 0);
    newObj(2, 27, 0, 1, 0, 3, array(0, 0, 0), array(0, 11, 0), array(0, 0, 0), array(0, 11, 0), 0, -1, 0, 'null', 0);
    newObj(3, 28, 0, 1, 0, 3, array(0, 0, 0), array(11, 0, 0), array(0, 0, 0), array(11, 0, 0), 0, -1, 0, 'null', 0);
    
    newObj(1, 29, 100, 100, 5, 4, array(18, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), -1, -1, 0, 'gold', 0);    
    newObj(1, 30, 0, 1, 0, 5, array(0, 0, 0), array(0, 0, 0), array(0, 0, 7), array(0, 0, 0), -1, 0, 0, 'null');
    newObj(2, 31, 50, 50, 5, 4, array(0, 0, 0), array(9, 0, 0), array(0, 0, 0), array(9, 0, 0), -1, -1, 0, 'gold', 0);
    newObj(3, 32, 50, 50, 5, 4, array(0, 0, 0), array(0, 0, 9), array(0, 0, 0), array(0, 0, 9), -1, -1, 0, 'gold', 0);
    
    newObj(0, 33, 0, 2, 5, 5, array(15, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), 1, -1, 0, 'null', 0);
    newObj(1, 34, 0, 2, 5, 5, array(0, 0, 15), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), 1, -1, 0, 'null', 0);
    newObj(2, 35, 0, 2, 5, 5, array(0, 15, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), 1, -1, 0, 'null', 0);
    newObj(3, 36, 0, 2, 5, 5, array(15, 0, 0), array(0, 0, 0), array(0, 0, 0), array(0, 0, 0), 1, -1, 0, 'null', 0);

    newObj(0, 37, 0, 2, 5, 6, array(20, 0, 0), array(20, 0, 0), array(20, 0, 0), array(20, 0, 0), -1, -1, 1, 'null', 0);
    newObj(1, 38, 0, 2, 5, 6, array(0, 20, 0), array(0, 20, 0), array(0, 20, 0), array(0, 20, 0), -1, -1, 1, 'null', 0);
    newObj(2, 39, 0, 2, 5, 6, array(20, 0, 0), array(20, 0, 0), array(20, 0, 0), array(20, 0, 0), -1, -1, 1, 'null', 0);
    newObj(3, 40, 0, 2, 5, 6, array(0, 0, 20), array(0, 0, 20), array(0, 0, 20), array(0, 0, 20), -1, -1, 1, 'null', 0);

    newObj(2, 41, 0, 2, 5, 7, array(0, 0, 0), array(0, 0, 0), array(0, 13, 0), array(0, 0, 0), -1, -1, -1, 'null', 6);
    newObj(1, 42, 0, 2, 5, 7, array(0, 0, 0), array(0, 0, 0), array(13, 0, 0), array(0, 0, 0), -1, -1, -1, 'null', 7);
    newObj(0, 43, 0, 2, 5, 7, array(0, 0, 0), array(0, 0, 0), array(0, 13, 0), array(0, 0, 0), -1, -1, -1, 'null', 7);

    newObj(2, 44, 500, 250, 15, 8, array(25, 0, 0), array(25, 0, 0), array(25, 0, 0), array(25, 0, 0), -1, -1, 0, 'gold', 0);
    newObj(0, 45, 500, 200, 15, 8, array(20, 0, 0), array(20, 0, 0), array(20, 0, 0), array(20, 0, 0), -1, -1, 0, 'gold', 0);
    newObj(3, 46, 500, 300, 15, 8, array(30, 0, 0), array(30, 0, 0), array(30, 0, 0), array(30, 0, 0), -1, -1, 0, 'gold', 0);
    newObj(1, 47, 500, 300, 15, 8, array(30, 0, 0), array(30, 0, 0), array(30, 0, 0), array(30, 0, 0), -1, -1, 0, 'gold', 0);

    newObj(1, 48, 0, 2, 5, 9, array(0, 0, 35), array(0, 0, 35), array(0, 0, 35), array(0, 0, 35), -1, -1, 0, 'null', 8);
    newObj(0, 49, 0, 2, 5, 9, array(0, 0, 15), array(0, 0, 15), array(0, 0, 15), array(0, 0, 15), -1, -1, 0, 'null', 7);
    newObj(3, 50, 0, 2, 5, 9, array(0, 0, 30), array(0, 0, 30), array(0, 0, 30), array(0, 0, 30), -1, -1, 0, 'null', 7);
    newObj(2, 51, 0, 2, 5, 9, array(0, 0, 30), array(0, 0, 30), array(0, 0, 30), array(0, 0, 30), -1, -1, 0, 'null', 7);

    newObj(0, 52, 0, 1, 0, 3, array(0, 20, 0), array(0, 20, 0), array(0, 20, 0), array(0, 20, 0), 3, -1, 0, 'null', 0);
    newObj(1, 53, 0, 1, 0, 3, array(0, 35, 0), array(0, 35, 0), array(0, 35, 0), array(0, 35, 0), 3, -1, 0, 'null', 0);
    newObj(3, 54, 0, 1, 0, 3, array(0, 30, 0), array(0, 30, 0), array(0, 30, 0), array(0, 30, 0), 3, -1, 0, 'null', 0);
    newObj(2, 55, 0, 1, 0, 3, array(0, 25, 0), array(0, 25, 0), array(0, 25, 0), array(0, 25, 0), 3, -1, 0, 'null', 0);
    
    $object->b = array(105);
    $object->craft = array(41,42,43,48,49,50,51);
    
    echo json_encode($object);
    
    function newObj($type, $id, $exp, $price, $level, $set, $winter, $spring, $summer, $autumn, $boss, $rayon, $sale, $valuta, $craft){
        global $object;
        
        $object->w[$id]->price = $price;
        $object->w[$id]->level = $level;
        $object->w[$id]->set = $set;
        $object->w[$id]->type = $type;
        $object->w[$id]->sale = $sale;
        $object->w[$id]->boss = $boss;
        $object->w[$id]->rayon = $rayon;
        $object->w[$id]->valuta = $valuta;
        $object->w[$id]->craft = $craft;
        
        $object->w[$id]->exp = $exp;
        $object->w[$id]->winter = $winter;
        $object->w[$id]->spring = $spring;
        $object->w[$id]->summer = $summer;
        $object->w[$id]->autumn  = $autumn;
    }
?>