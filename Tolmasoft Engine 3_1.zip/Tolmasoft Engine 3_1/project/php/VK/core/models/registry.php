<?php

	Class Registry Implements ArrayAccess {

        private $vars = array('damages'=>array(7,13,20,30,50,300,20),
        		      'functions'=>array('getToken', 
        					 'getLinks', 
        					 'getUI', 
        					 'getGT', 
        					 'getFT', 
        					 'getLT', 
        					 'getLcsI', 
        					 'getW', 
        					 'getML', 
        					 'getBS', 
        					 'getWeap', 
        					 'getDon', 
        					 'getBon', 
        					 'getWrs', 
        					 'shmon', 
        					 'gtP', 
        					 'snatWear', 
        					 'odetWear', 
        					 'buyWear', 
        					 'getBonus', 
        					 'udarBoss', 
        					 'buyWeap', 
        					 'goFight', 
        					 'getSB', 
        					 'startMG', 
        					 'setMG', 
        					 'newName', 
        					 'updateWork', 
        					 'takeWork', 
        					 'buyE', 
        					 'goQuest', 
        					 'getLI', 
        					 'getAch', 
        					 'getMandat', 
                             'upMandat',
        					 'nullMandat',
                             'getHobo',
                             'obmenVal'),
        		      'names'=>array('Чирий', 
        				     'Трэш', 
        				     'Тыр', 
        				     'Клямпер', 
        				     'Мальчик', 
        				     'Бэн', 
        				     'Силя', 
        				     'Батон', 
        				     'Сика', 
        				     'Шапито', 
        				     'Репа', 
        				     'Мозг', 
        				     'Лещ', 
        				     'Молодой', 
        				     'Панк', 
        				     'Пышный', 
        				     'Бух', 
        				     'Губастый', 
        				     'Клюй', 
        				     'Васёк', 
        				     'Нос', 
        				     'Фрол', 
        				     'Базай', 
        				     'Воробей', 
        				     'Питон', 
        				     'Люссак', 
        				     'Пидаль', 
        				     'Блин', 
        				     'Федот', 
        				     'Боб', 
        				     'Зевс', 
        				     'Вавилон', 
        				     'Гондурас', 
        				     'Кабан', 
        				     'Гас', 
        				     'Байс', 
        				     'Треск', 
        				     'Песняр', 
        				     'Мультик', 
        				     'Сметана', 
        				     'Робин', 
        				     'Пыр', 
        				     'Божинда', 
        				     'Пузо', 
        				     'Руль', 
        				     'Баур', 
        				     'Гоблин', 
        				     'Жид', 
        				     'Зверь', 
        				     'Тролль', 
        				     'Стакан', 
        				     'Леший', 
        				     'Пирда', 
        				     'Питон', 
        				     'Чужой', 
        				     'Бидон', 
        				     'Чинарик'),
        		      'api_service'=>'1a6082b41a6082b41a6082b4131a3d264911a601a6082b443e523089be0df9d3af3bc18',
        		      'api_secret'=>'lOcc0ByZBOe4SwODBeW1',
        		      'api_id'=>6137085,
        		      'server'=>'localhost',
        		      'user'=>'root',
        		      'pass'=>'yRPWT5FkMz',
        		      'db'=>'xuli',
                              'utb'=>'users',
        		      'emax'=>50,
        		      'btb'=>'fights');

        function set($key, $var) {
	        if (isset($this->vars[$key]) == true) return false;

	        $this->vars[$key] = $var;

	        return true;
		}

		function get($key) {
		   	if (isset($this->vars[$key]) == false) return null;

		    return $this->vars[$key];
		}

	function remove($var) {
		unset($this->vars[$key]);
	}

		//Standart functions about interface ArrayAcces

	function offsetExists($offset) {
        	return isset($this->vars[$offset]);
	}

	function offsetGet($offset) {
		    return $this->get($offset);
	}

	function offsetSet($offset, $value) {
		    $this->set($offset, $value);
	}

	function offsetUnset($offset) {
		    unset($this->vars[$offset]);
	}

	}

?>