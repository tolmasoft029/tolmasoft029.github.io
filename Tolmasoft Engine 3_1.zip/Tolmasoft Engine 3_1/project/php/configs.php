﻿<?php
    $mts = array('getToken', 'getLinks', 'getUI', 'getGT', 'getFT', 'getLT', 'getLcsI', 'getW', 'getML', 'getBS', 'getWeap', 'getDon', 'getBon', 'getWrs', 'learnCompl', 'shmon', 'gtP', 'snatWear', 'odetWear', 'buyWear', 'getBonus', 'udarBoss', 'buyWeap', 'goFight', 'getSB', 'startMG', 'setMG', 'newName', 'updateWork', 'takeWork', 'buyE', 'goQuest', 'getLI', 'getAch', 'getMandat', 'upMandat');//список методов???
    $func = array(array(0, 'token'));
    $user = "xuli_user"; //пользователь БД
    $password = "tolmasoft1"; //пароль пользователя БД
    $server = "localhost"; //сервер с БД
    $db = "xuli"; //название рабочей БД   
    $table = "users";//название рабочей таблицы
    $Btable = 'fights';//название таблицы с боссами
    $robot = 'robot';//название таблицы робота
    $fldb = 'flauth';//название БД FLauth
    $fltable = 'users';//название таблицы FLauth
    $secret = 'GltnXaT67MYKdwXEFVpC';//секретный ключ игры
    $service = 'ac5caadfac5caadfac5caadf8dac0ba8e3aac5cac5caadff64ff9ece2de3b5a853d6caf';//сервисный токен
    $api_id = 5702204;//ид игры
   ?>